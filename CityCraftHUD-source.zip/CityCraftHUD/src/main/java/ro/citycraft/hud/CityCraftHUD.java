package ro.citycraft.hud;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.boss.BarColor;
import org.bukkit.boss.BarStyle;
import org.bukkit.boss.BossBar;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitTask;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class CityCraftHUD extends JavaPlugin implements Listener {
    private final Map<UUID, BossBar> bars = new ConcurrentHashMap<>();
    private final Map<UUID, Long> joinedAt = new ConcurrentHashMap<>();
    private BukkitTask updater;
    private String titleTemplate;
    private boolean showDate;
    private boolean showPlaytime;
    private String moneyPlaceholder;
    private String rankPlaceholder;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        titleTemplate = getConfig().getString("title", "&6&lCITYCRAFT &8| &f%player%");
        showDate = getConfig().getBoolean("show-date", true);
        showPlaytime = getConfig().getBoolean("show-playtime", true);
        moneyPlaceholder = getConfig().getString("money-placeholder", "");
        rankPlaceholder = getConfig().getString("rank-placeholder", "");
        Bukkit.getPluginManager().registerEvents(this, this);

        for (Player player : Bukkit.getOnlinePlayers()) {
            joinedAt.putIfAbsent(player.getUniqueId(), System.currentTimeMillis());
            createBar(player);
        }

        long period = Math.max(20L, getConfig().getLong("refresh-ticks", 40L));
        updater = Bukkit.getScheduler().runTaskTimer(this, () -> {
            for (Player player : Bukkit.getOnlinePlayers()) updateBar(player);
        }, 1L, period);
        getLogger().info("CityCraftHUD enabled. This starter uses a boss bar; graphical logo/resource-pack rendering is not yet implemented.");
    }

    @Override
    public void onDisable() {
        if (updater != null) updater.cancel();
        bars.values().forEach(BossBar::removeAll);
        bars.clear();
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        joinedAt.put(event.getPlayer().getUniqueId(), System.currentTimeMillis());
        createBar(event.getPlayer());
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        BossBar bar = bars.remove(event.getPlayer().getUniqueId());
        if (bar != null) bar.removeAll();
        joinedAt.remove(event.getPlayer().getUniqueId());
    }

    private void createBar(Player player) {
        BossBar bar = bars.computeIfAbsent(player.getUniqueId(),
                id -> Bukkit.createBossBar("CityCraft", BarColor.YELLOW, BarStyle.SOLID));
        bar.addPlayer(player);
        bar.setVisible(true);
        updateBar(player);
    }

    private void updateBar(Player player) {
        BossBar bar = bars.get(player.getUniqueId());
        if (bar == null) return;

        String title = ChatColor.translateAlternateColorCodes('&', titleTemplate)
                .replace("%player%", player.getName());

        String rank = resolvePlaceholder(player, rankPlaceholder);
        String money = resolvePlaceholder(player, moneyPlaceholder);
        StringBuilder info = new StringBuilder(title);

        if (!rank.isBlank()) info.append(ChatColor.GRAY).append("  |  ").append(ChatColor.GOLD).append(rank);
        if (!money.isBlank()) info.append(ChatColor.GRAY).append("  |  ").append(ChatColor.GREEN).append(money);

        LocalDateTime now = LocalDateTime.now();
        if (showDate) {
            info.append(ChatColor.GRAY).append("  |  ")
                .append(ChatColor.WHITE).append(now.format(DateTimeFormatter.ofPattern("HH:mm dd.MM.yyyy")));
        }
        if (showPlaytime) {
            long start = joinedAt.getOrDefault(player.getUniqueId(), System.currentTimeMillis());
            long minutes = Math.max(0, (System.currentTimeMillis() - start) / 60000L);
            info.append(ChatColor.GRAY).append("  |  ")
                .append(ChatColor.AQUA).append("Sesiune: ").append(minutes).append("m");
        }

        bar.setTitle(info.toString());
        bar.setProgress(1.0);
    }

    private String resolvePlaceholder(Player player, String placeholder) {
        if (placeholder == null || placeholder.isBlank()) return "";
        if (Bukkit.getPluginManager().isPluginEnabled("PlaceholderAPI")) {
            try {
                Class<?> papi = Class.forName("me.clip.placeholderapi.PlaceholderAPI");
                return (String) papi.getMethod("setPlaceholders", Player.class, String.class)
                        .invoke(null, player, placeholder);
            } catch (ReflectiveOperationException ex) {
                getLogger().warning("Could not resolve PlaceholderAPI value: " + ex.getMessage());
            }
        }
        return "";
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!command.getName().equalsIgnoreCase("cityhud")) return false;
        if (!(sender instanceof Player player)) {
            sender.sendMessage("This command is for players.");
            return true;
        }
        if (!player.hasPermission("citycrafthud.toggle")) {
            player.sendMessage(ChatColor.RED + "Nu ai permisiunea.");
            return true;
        }
        BossBar bar = bars.get(player.getUniqueId());
        if (bar == null) {
            createBar(player);
            player.sendMessage(ChatColor.GREEN + "CityCraft HUD activat.");
        } else {
            bar.setVisible(!bar.isVisible());
            player.sendMessage(ChatColor.YELLOW + "CityCraft HUD " + (bar.isVisible() ? "activat." : "dezactivat."));
        }
        return true;
    }
}
