# CityCraftHUD — starter project

Target: Minecraft 1.20.1 / Java 17 / Bukkit-compatible server layer.

## Important limitation
This is a **starter plugin**, not the finished graphical HUD requested. It currently displays information through a boss bar as a compatibility-safe first step. It does not yet generate or deliver a resource pack, render the CityCraft logo as an image, or read Good Ol' Currency directly.

Good Ol' Currency is a Minecraft mod. Do not assume Vault or PlaceholderAPI can read its balance. First confirm the exact mod version and whether Arclight exposes an API/bridge that another plugin can call.

## Build
1. Install a Java 17 JDK and Maven.
2. Open a terminal in this folder.
3. Run: `mvn clean package`
4. The output will be `target/CityCraftHUD.jar`.
5. Stop the server, back up the server folder, copy the JAR into `plugins/`, then start the server and inspect the console.

## Use
- `/cityhud` toggles the current display.
- Configure `plugins/CityCraftHUD/config.yml`.
- `money-placeholder` and `rank-placeholder` remain blank until you have verified valid PlaceholderAPI placeholders.
- `Sesiune` means time since joining this session, not total lifetime playtime.

## Next development step
For the requested image-based HUD at the top of the screen, add a compatible custom-font/resource-pack rendering pipeline and pack delivery. Test it on the exact Arclight build and client version. A normal Bukkit plugin cannot simply draw arbitrary pixels on the client screen.
